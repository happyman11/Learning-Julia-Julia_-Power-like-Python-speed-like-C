# Starting example file for working with chars and strings in Julia

# TODO: Julia has a specific character type


# Strings are defined using double quotes or triple quotes
mystr = "This is a sample string in Julia"
myotherstr = """
    Hello There
    This is a string
    """

# TODO: Get the length of a string


# TODO: Access individual characters - note that they are 1-indexed


# TODO: Slicing strings is used with the : notation


# TODO: Iterate over characters


# TODO: String concatenation using *


# TODO: String interpolation


