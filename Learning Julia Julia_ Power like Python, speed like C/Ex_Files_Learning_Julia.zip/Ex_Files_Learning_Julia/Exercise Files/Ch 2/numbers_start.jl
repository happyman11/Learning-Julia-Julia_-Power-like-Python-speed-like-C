# Starting example file for Julia number types

# TODO: Julia defines a set of specific sub-types for numbers
# Signed integers: Int, Int8, Int16, Int32, Int64, BigInt


# TODO: Unsigned integers: UInt, UInt8, UInt16, UInt32, UInt64


# TODO: typemax() and typemin() will provide max and min values


# TODO: Use the WORDSIZE property to see what type of system this is 


# TODO: trying to assign a number too large for the type
# will fail and give an error


# TODO: special values represent Infinity and not-a-number


# TODO: zero() and one() functions produce values for a given type
