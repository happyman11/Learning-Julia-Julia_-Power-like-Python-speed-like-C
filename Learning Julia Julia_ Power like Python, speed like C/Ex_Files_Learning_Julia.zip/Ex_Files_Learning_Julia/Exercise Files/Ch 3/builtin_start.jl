# Starting example for built in functions in Learning Julia


# numeric functions
# TODO: round, floor, ceil, abs


# text i/o
# TODO: print, println


# TODO: printstyled


# read standard input
# TODO: readline


# TODO: "is" functions
# println(isascii("abc"))
# println(isascii("αβγ"))

# println(isdigit('9'))
# println(isdigit('a'))

# println(isspace(' '))
# println(isspace('\r'))
# println(isspace('\n'))
# println(isspace('A'))
