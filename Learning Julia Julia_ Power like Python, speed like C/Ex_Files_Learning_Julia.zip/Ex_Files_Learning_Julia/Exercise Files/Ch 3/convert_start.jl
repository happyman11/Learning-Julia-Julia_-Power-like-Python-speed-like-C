# Starting point example for converting data types in Learning Julia

# declare some basic data types
x = 10
y = 20.0
z = "40"
f = "30.0"

# TODO: Convert an integer to a character and vice versa


# TODO: convert between types


# TODO: parse values from a string


# TODO: attempting to convert a data type that won't fit is an error

