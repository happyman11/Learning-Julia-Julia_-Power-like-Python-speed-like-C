# Starting file system example for Learning Julia

# TODO get the current workding dir
# print("Current working directory: ")


# TODO read the contents of the current directory
# print("Current directory contents: ")


# TODO open a file for writing


# TODO open a file for reading


# TODO append data to an existing file



# TODO rename an existing file


# TODO delete a file

