# Starting sorting example for Learning Julia

arr1 = [2, 8, -3, -15, 5, -7, 9, 0, 11]

# TODO sort the data by a simple transformation


# TODO check to see if an array is already sorted
arrtup = [(1, 2), (2, 1), (3, 5), (4, 0)]


# Sorting custom types
struct MyRect
    length::Int
    width::Int
end

arr2 = [MyRect(12, 22), MyRect(10, 18),MyRect(7, 12),MyRect(9, 30)]

# TODO declare a custom sorting function

