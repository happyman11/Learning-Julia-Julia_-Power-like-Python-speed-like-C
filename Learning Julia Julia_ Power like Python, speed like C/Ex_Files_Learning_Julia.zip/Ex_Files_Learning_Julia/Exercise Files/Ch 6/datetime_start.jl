# Starting point date and time example for Learning Julia

# import the Dates module to use the code it contains
using Dates

# TODO create new Date and DateTime


# TODO parse a date or date/time string using DateFormat


# TODO differences between Dates and Times


# TODO access the values of a date or time


# TODO query functions


# TODO adjuster functions
