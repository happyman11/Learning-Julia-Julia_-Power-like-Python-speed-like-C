# Starting random numbers example for Learning Julia
using Random

# TODO: generate a random number between 0 and 1


# TODO: pick a random element from a given collection


# TODO: populate an array with random values


# TODO: generate a random string


# TODO: shuffle a list of elements
vowels = ["A","E","I","O","U"]


# TODO: use the seed function to control the random number generator
