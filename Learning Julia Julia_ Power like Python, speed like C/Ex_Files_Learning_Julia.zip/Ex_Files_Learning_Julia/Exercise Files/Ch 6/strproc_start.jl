# Starting string processing example for Learning Julia


# TODO: simple string operations - length, size
mystr = "Ångström"
teststr = "jμΛIα" # test string with some Greek characters


# TODO: concatenation and repetition operators


# TODO: search for substrings
teststr = "Julia programming is awesome"


# TODO: pad strings either left or right


# TODO: create a string from an array
arr = ["Lions","Tigers","Bears"]

