# Starting custom types example file for Learning Julia

# TODO Create a new custom type using the struct keyword


# TODO instantiate the type


# TODO use "mutable" to make a type that can be altered


# TODO use the isa() method to see if a variable is a given type

