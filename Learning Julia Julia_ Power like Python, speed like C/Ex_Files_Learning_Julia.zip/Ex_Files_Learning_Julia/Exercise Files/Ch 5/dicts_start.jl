# Starting point for dictionaries example for Learning Julia
# Dictionaries map unique keys to individual values

# TODO: Create a new dictionary


# TODO: look up an item


# TODO: Add an item to a dictionary


# TODO: Test to see if an item is in a dictionary


# TODO: remove an item from a dictionary


# TODO: get all the keys and values as arrays


# TODO: Iterate over a dictionary's keys and values
