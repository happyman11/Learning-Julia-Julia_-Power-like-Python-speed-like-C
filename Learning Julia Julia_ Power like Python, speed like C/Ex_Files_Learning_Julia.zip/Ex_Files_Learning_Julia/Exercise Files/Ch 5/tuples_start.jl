# Starting point for tuples example for Learning Julia

# TODO: a tuple is a sequence of values and is immutable once defined
# like an array, it can contain different types


# TODO: Tuples can be iterated over like arrays


# TODO: The "in" operator can be used to see if a tuple contains a value


# TODO: tuples can have multiple dimensions


# TODO: attempting to modify a tuple will produce an error


# TODO: Named Tuples provide a way to associate names with tuple values

