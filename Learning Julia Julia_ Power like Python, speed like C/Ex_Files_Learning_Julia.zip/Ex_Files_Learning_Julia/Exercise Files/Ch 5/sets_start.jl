# Starting point for sets example for Learning Julia

# A set is a collection of elements like an array or dictionary
# but a set can only contain one of each element and the ordering
# of elements is not important

# TODO: create a new empty set


# TODO: create a set from a collection of values


# When Julia determines a set type, you can't add different types


# TODO: create a set of a given type


# many of the array operations also work with sets
# TODO: use the in operator to see if a set contains an item


# TODO: however, since there's no order, something like an index causes an error


# TODO: you can calculate set intersections, differences, and unions
primarycolors = Set(["red","yellow","green","blue"])
pastels = Set(["teal","pink","lavender","coral"])
