# Starting point for Arrays example file for Learning Julia

# TODO: create an array using [] syntax


# TODO: access an array element - array indexes are 1-based


# TODO: arrays can hold different types of values


# TODO: declare an array with a particular type


# TODO: populate an array - fill wth default values


# TODO: Array sorting using the sort function


# TODO: sort! modifies the original array in place


# TODO: Convert to string with a delimiter

