# Starting functions example for Learning Julia

# TODO: Functions are defined with the function keyword and are usually
# lowercase names, optionally with underscores if they are hard to read


# TODO: function arguments can have default values


# TODO: you can also use keyword arguments - define them after a semicolon


# TODO: The Julia shorthand way of defining a function 


# TODO: use the ... notation for variable arguments
function summit()
    sum = 0
    # TODO: process each argument

    return sum
end
# println(summit(1, 5, 10))
# println(summit(2, 4, 6, 8))

