# Starting point for loops example for Learning Julia

# TODO: basic for loop


# TODO: can be any iterable, not just a range


# TODO: Nested for loop


# TODO: while loop


# TODO: Using enumeration within a loop
teams = ("Giants", "Wizards", "Dragons", "Knights", "Kings")


# TODO: Loop control - breaking and continuing
# for i in 1:10
#     println(i)
# end

