# Starting point for conditional example for Learning Julia

# TODO: Create an if-else conditional
x = 5


# TODO: multiple conditions can be specified with if-elseif-else


# TODO: The ternary operator can condense a comparison

